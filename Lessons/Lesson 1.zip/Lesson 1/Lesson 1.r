
#BRIEF 

#Here we will be looking at the popular different ways data can be presented in the R Language

#ggplot is a popular open source library used to plot data, it supports many different graphs and charts.

# Ggplot2 library
library(ggplot2)

#In this example we will be exploring bar charts. With bar charts, the numerical values are represented by the height of the bars.
#In this example, we can see the Bar Chart for a group of students and their scores on a test 
#Bar charts can be used to represent both discrete and continous data
#Bar charts are useful because they are easy to read and they are simple to create, as you can see it only takes a few lines of code.

# Create data
data=data.frame(name=c("Jake","Sarah","Chris","Ben","Jessica") ,  score_on_test=c(15,12,32,20,40))

# Barplot
ggplot(data, aes(x=name, y=score_on_test)) + geom_bar(stat = "identity")

#In the next exmaple we will be exploring pie charts in R
#pie charts are useful when presenting nomial or ordinal data

#calculuating angles on a pie chart: (f/t)*360 -> the reason why we multiply by 360 is because a circle adds up to a total of 360
#where f = frequency and t = total frequency
#in R we can simply use the pie() function in order to create a pie chart

score_on_test=c(15,12,20,30,40)

pie(score_on_test)

#In the next example we will be taking a look at histograms
#A histogram is used to plot the frequency of occurrences within a continuous data set that has been divided into classed (bins)
#on the y-axis the frequency density is labelled and on the x-axis the ranges of values or continuous categories.

#HELPFUL FORMULAS:
#range_between_values_in_data = maximum_value - minimum_value
#number_of_class_intervals = sqrt(number_of_data_points)
#class_width = range / number_of_class_intervals
#frequency_density = frequency / class width
#area_of_histogram = sum(frequency_density) * sum(class_width) 
# Also, the skewness of the distribution can be determined, as if the bars on the left or the right are higher then it indicates that the data is skewed

#sample_dataset = 13,34,23,44,31,56
#sample_dataset_cumulative_frequency = 13,47,70,114,145,201
#median = sum(cumulative frequency) / 2
#cumulative_relative_frequency = cumulative_frequency / sample_size
#percentiles = (pm = m/100 / N) 
#For example, suppose you have 25 test scores, and in order from lowest to highest they look like this: 43, 54, 56, 61, 62, 66, 68, 69, 69, 70, 71, 72, 77, 78, 79, 85, 87, 88, 89, 93, 95, 96, 98, 99, 99. To find the 90th percentile for these (ordered) scores, start by multiplying 90% times the total number of scores, which gives 90% ∗ 25 = 0.90 ∗ 25 = 22.5 (the index). Rounding up to the nearest whole number, you get 23.
#Counting from left to right (from the smallest to the largest value in the data set), you go until you find the 23rd value in the data set. That value is 98, and it’s the 90th percentile for this data set.

time <- c(21,18,17,1,21,22,54,46,25,39,43,41,55,49,38,59,10)

summary(time)

class_width <- (ceiling((59-1)/5)) #remember, class width must be a whole number. so this can be rounded up to 12, we cn do this using the ceiling() function

print(class_width)

breaks <- seq(1,65,class_width) #this shows the classes

print(breaks)

time_cut <- cut(time,breaks,right=FALSE)

print(time_cut)

time_freq <- table(time_cut) #creates a frequency table 

time_hist = hist(time_freq, xlab="class_width", ylab = "frequency") #create the histogram

print(time_hist)

time_cumulative = cumsum(time_freq) #create the cumulative frequency

barplot(time_cumulative, xlab = "class_width", ylab = "frequency_density") #make a bar plot of the cumulative frequency

#hist
#cumsum

#next we will look at scatter graphs 
#scatter graphs are easy to interpret, it is easier to point out anomilies, it shows correlation in the data.

# import ggplot2
library(ggplot2)

# The iris dataset is proposed by R
head(iris)

# basic scatterplot
ggplot(iris, aes(x=Sepal.Length, y=Sepal.Width)) + 
    geom_point()
